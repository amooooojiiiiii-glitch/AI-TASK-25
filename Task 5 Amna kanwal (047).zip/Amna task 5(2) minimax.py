visited = 0

scores = [2, 4, 6, 8, 1, 3, 5, 7]

depth = 3


def minimax(level, position, maxPlayer, depth):

    global visited

    if level == depth:
        visited += 1
        return scores[position]

    if maxPlayer:

        left = minimax(level + 1, position * 2, False, depth)

        right = minimax(level + 1, position * 2 + 1, False, depth)

        if left > right:
            return left
        else:
            return right

    else:

        left = minimax(level + 1, position * 2, True, depth)

        right = minimax(level + 1, position * 2 + 1, True, depth)

        if left < right:
            return left
        else:
            return right


result = minimax(0, 0, True, depth)

print("Best Value:", result)
print("Visited Nodes:", visited)