# DLS

graph = {
    "A": ["B", "C"],
    "B": ["D", "E"],
    "C": ["F"],
    "D": [],
    "E": ["G"],
    "F": [],
    "G": ["H"],
    "H": []
}


def DLS(start, goal, limit):

    stack = [(start, [start])]
    visited = []
    cutoff = False

    while len(stack) > 0:

        node, path = stack.pop()
        visited.append(node)

        if node == goal:
            return "Found", path, visited

        depth = len(path) - 1

        if depth >= limit:
            if graph[node] != []:
                cutoff = True

        else:
            for child in reversed(graph[node]):
                if child not in path:
                    newPath = path + [child]
                    stack.append((child, newPath))

    if cutoff == True:
        return "Cutoff", None, visited

    return "Failure", None, visited


for depthLimit in [1, 2, 3, 4]:

    status, path, visited = DLS("A", "H", depthLimit)

    print("Limit:", depthLimit)
    print("Status:", status)
    print("Path:", path)
    print("Visited:", visited)

    if status == "Found":
        break