graph = {
    "A": {"B": 2, "C": 4},
    "B": {"D": 2},
    "C": {"E": 3},
    "D": {"C": 2, "E": 4},
    "E": {"G": 7},
    "G": {}
}

heuristic = {
    "A": 20, "B": 4, "C": 3,
    "D": 5, "E": 10, "G": 0
}

def searchPath(heuristic, searchType):
    paths = [("A", 0, ["A"])]
    costs = {"A": 0}
    visited = []
    print("\n", searchType)
    while len(paths) > 0:
        paths.sort(key=lambda x: x[1] + heuristic[x[0]])

        current, cost, route = paths.pop(0)

        if cost > costs[current]:
            continue

        visited.append(current)
        priority = cost + heuristic[current]

        print("Node:", current)
        print("Cost:", cost)
        print("Priority:", priority)

        if current == "G":
            print("Path:", " -> ".join(route))
            print("Total Cost:", cost)
            print("Visited:", visited)
            return

        for node in graph[current]:

            distance = graph[current][node]
            newCost = cost + distance

            if node not in costs or newCost < costs[node]:

                costs[node] = newCost

                newRoute = route + [node]

                paths.append((node, newCost, newRoute))


searchPath(heuristic, "A Star Search")

zeroHeuristic = {}

for node in graph:
    zeroHeuristic[node] = 0

searchPath(zeroHeuristic, "Uniform Cost Search")

changedHeuristic = heuristic.copy()
changedHeuristic["C"] = 15

searchPath(changedHeuristic, "Modified A Star Search")