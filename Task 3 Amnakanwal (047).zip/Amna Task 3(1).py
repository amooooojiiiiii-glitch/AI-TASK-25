#BFS AND DFS

#BFS
graph = {
    "A": ["B", "C"],
    "B": ["D", "E"],
    "C": ["F"],
    "D": [],
    "E": [],
    "F": ["G"],
    "G": []
}
visited = []
queue = []

def bfs(start):

    queue.append(start)

    while queue:
        current = queue.pop(0)

        if current not in visited:
            print(current, end=" ")
            visited.append(current)

            for node in graph[current]:
                queue.append(node)
PRINT("BFS;")
bfs("A")
# DFS
visited = []
stack = []

def dfs(start):

    stack.append(start)

    while stack:
        current = stack.pop()

        if current not in visited:
            print(current, end=" ")
            visited.append(current)

            for node in reversed(graph[current]):
                stack.append(node)

PRINT("DFS;")
dfs("A")