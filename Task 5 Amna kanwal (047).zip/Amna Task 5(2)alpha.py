visited = 0

def alphaBeta(level, position, maxPlayer, values, limit, alpha, beta):

    global visited

    if level == limit:
        visited += 1
        return values[position]

    if maxPlayer:
        best = float("-inf")

        for i in range(2):

            result = alphaBeta(
                level + 1,
                position * 2 + i,
                False,
                values,
                limit,
                alpha,
                beta
            )

            if result > best:
                best = result

            if best > alpha:
                alpha = best

            if alpha >= beta:
                break

        return best

    else:
        best = float("inf")

        for i in range(2):

            result = alphaBeta(
                level + 1,
                position * 2 + i,
                True,
                values,
                limit,
                alpha,
                beta
            )

            if result < best:
                best = result

            if best < beta:
                beta = best

            if alpha >= beta:
                break

        return best


values = [4, 6, 2, 8, 3, 7, 1, 9]

limit = 3

answer = alphaBeta(
    0, 0, True, values, limit,
    float("-inf"), float("inf")
)

print("Best Value:", answer)
print("Visited Nodes:", visited)