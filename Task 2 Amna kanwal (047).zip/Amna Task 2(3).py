def chooseMode(temp, occupied, oldMode):

    if occupied == False:
        mode = "ECO"
    elif temp > 26:
        mode = "COOL"
    elif temp < 20:
        mode = "WARM"
    else:
        mode = "IDLE"

    if mode == oldMode:
        return mode, False
    else:
        return mode, True

roomData = [
    (29, True),
    (29, True),
    (25, True),
    (20, True),
    (17, True),
    (17, False)
]
previousMode = None
for temp, occupied in roomData:
    currentMode, command = chooseMode(temp, occupied, previousMode)
    print("Old Mode:", previousMode)
    print("Temperature:", temp)
    print("Room Occupied:", occupied)
    print("New Mode:", currentMode)

    if command == True:
        print("Command Sent")
    else:
        print("No Command Needed")

    print()
    previousMode = currentMode