def checkApplication(score, documents, projects, days):
    issues = []

    if score < 70:
        issues.append("Score is low")

    if not documents:
        issues.append("Documents are missing")

    if projects < 70:
        issues.append("Projects are low")

    if days > 7:
        issues.append("Application is late")

    if len(issues) == 0:
        return "Review", "Requirements are complete"
    else:
        return "Hold", ", ".join(issues)


students = [
    ("Student 1", 80, True, 3, 4, "Review"),
    ("Student 2", 65, True, 2, 5, "Hold"),
    ("Student 3", 75, False, 4, 8, "Hold"),
    ("Student 4", 90, True, 3, 6, "Review")
]

for name, score, documents, projects, days, expected in students:

    result, reason = checkApplication(score, documents, projects, days)

    print("Name:", name)
    print("Score:", score)
    print("Documents:", documents)
    print("Projects:", projects)
    print("Days:", days)
    print("Expected:", expected)
    print("Actual:", result)
    print("Reason:", reason)
    print("Test Passed:", expected == result)
    print()